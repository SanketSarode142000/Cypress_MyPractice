describe('You Tube', () => {
    it('Video Play', () => {
        cy.visit('https://www.youtube.com/');
    //    cy.get('#search').click();
    cy.get('#search-input > #search').click().type("Phir hera pheri");
    // cy.get('#button').click()
    cy.get('#center').click()
    cy.xpath('//button[@aria-label="Search"]').click()
    // cy.xpath('//button[@aria-label="Search"]').click()
    // cy.xpath('//button[@aria-label="Search"]').click({ multiple: true });
    // cy.get(':nthn-child(2) > #dismissible').click();
    // cy.get('.yt-icon-shape style-scope yt-icon yt-spec-icon-shape').click();






        // cy.get('.style-scope ytd-mini-guide-renderer').click()
        // cy.get('.style-scope ytd-guide-entry-renderer').click();
        // cy.get('[aria-label="Subscriptions"]').click();
        


        // cy.get(':nth-child(6) > :nth-child(1) > #content > .ytd-rich-item-renderer > #dismissible > #details > #meta > h3.style-scope > #video-title-link > #video-title').click()
        // cy.get('#end > #buttons > ytd-button-renderer.style-scope > yt-button-shape > .yt-spec-button-shape-next > yt-touch-feedback-shape > .yt-spec-touch-feedback-shape > .yt-spec-touch-feedback-shape__fill').click()




        // cy.get('#search-form').type("ye gopal ke bacche ka kuch karna padega golmaal fun unlimited arshad warsi sharman tusshar");
        // //cy.get('#title style-scope ytd-guide-entry-renderer').click();




        // // // cy.get('#style-scope ytd-video-renderer').click();
        //  cy.xpath('//button[@aria-label="Search"]');
        // // // cy.get('#search-icon-legacy').click();
        // cy.get('#search-icon-legacy').click()
        // // cy.get('#yt-icon-shape style-scope yt-icon yt-spec-icon-shape')
        // // // cy.xpath('//yt-formatted-string[@aria-label="ye gopal ke bacche ka kuch karna padega | Golmaal Fun Unlimited |  Arshad Warsi, Sharman, Tusshar by Ajay और Akshay 15,616,296 views 2 years ago 27 minutes"]')
        // cy.get('#search-input > #search').click();
        // // cy.get('#search-input > #search').type('testers talk');
        // // cy.get('#search-icon-legacy > yt-icon.style-scope > .style-scope');
        // // cy.get('.ytd-channel-renderer').click();
        // cy.xpath('//yt-formatted-string[@class="style-scope ytd-video-renderer"]').click();
   
   
   
    });
});





// describe('OrangeHrm', () => {
//     it('Login', () => {
//         cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/auth/login');
//         // cy.xpath('//input[@name="username"]').click();


//         // cy.xpath('//input[@name="username"]').should('be.visible');
//         // cy.xpath('//input[@placeholder="Password"]').should('be.visible');
//         cy.xpath('//input[@name="username"]').should('not.exist');


//         // cy.xpath('//input[@name="username"]').should('exist');
     
//     });

    it('Login', () => {
        cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/auth/login');
        // cy.xpath('//input[@name="username"]').click();

        cy.xpath('//input[@name="username"]').should('be.visible');
        // cy.xpath('//input[@name="username"]').should('not.be.visible');
        cy.xpath('//input[@name="username"]').should('exist');
        cy.xpath('//input[@name="username"]').type('Admin').should('have.value','Admin');
        cy.xpath('//input[@name="username"]').should('have.attr','name','username');    // checks placeholder properly displayed or not
    });


    it('Login', () => {
        cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/auth/login');
        
        cy.get('[type="submit"]').should('have.text',' Login ')
        // cy.get('[type="submit"]').should('have.text','Login')

        cy.get('[type="submit"]').should('have.text',' Login ')

        cy.get('[type="submit"]').should('include.text','in')
        cy.get('[type="submit"]').should('contains.text','gin')



    });


//     it('Final login', () => {
//         cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/auth/login');

//         cy.xpath('//input[@placeholder="Username"]').click().type("Admin");
//         cy.xpath('//input[@placeholder="Password"]').click().type("admin123");
//         cy.xpath('//button[@type="submit"]').click();


//         cy.get('.oxd-text--span.oxd-main-menu-item--name').click({multiple :true});
//         // :nth-child(1) > .oxd-main-menu-item > .oxd-text



//     });

// });



