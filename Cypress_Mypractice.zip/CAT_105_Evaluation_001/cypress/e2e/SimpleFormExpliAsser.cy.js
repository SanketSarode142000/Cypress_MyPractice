describe('Simple Form', () => {
    it('Simple Form', () => {
        cy.visit('https://v1.training-support.net/selenium/simple-form');
        cy.get('#firstName').then((firstVar) => {
            expect(firstVar).to.have.attr('placeholder','First Name');
            // expect(firstVar).to.have.attr('type','text');
            cy.wrap(firstVar).type("Sanket");
        });
    });
    it('Explicit assertion', () => {
        cy.visit('https://v1.training-support.net/selenium/simple-form');
        cy.get('#lastName').then((secondVar) => {
            expect(secondVar).to.have.attr('placeholder','Last Name');
            cy.wrap(secondVar).type("Sarode");
        });       
    });
    it('Explicit assertion', () => {
        cy.visit('https://v1.training-support.net/selenium/simple-form');
        cy.xpath('//input[@placeholder="abc@xyz.com"]').then((thirdVar) => {
            expect(thirdVar).to.have.attr('placeholder','abc@xyz.com');
            cy.wrap(thirdVar).type("sanket142000@gmail.com");
        })       
    });


});