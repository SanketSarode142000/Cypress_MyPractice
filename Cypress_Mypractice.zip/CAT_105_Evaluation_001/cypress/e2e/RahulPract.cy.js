describe('Rahul Practise Total', () => {
    it('Radio 1, 2, 3 click', () => {
        cy.visit('https://rahulshettyacademy.com/AutomationPractice/');
        cy.title().should('includes', 'Practice Page');
        cy.xpath('//input[@value="radio1"]').click();
        cy.xpath('//input[@value="radio2"]').click();
        cy.xpath('//input[@value="radio3"]').click();
        // cy.get('input[value="radio2"]').check().should('be.checked')      
    });

    
    it('Type countries', () => {
        cy.visit('https://rahulshettyacademy.com/AutomationPractice/');
        cy.xpath('//input[@placeholder="Type to Select Countries"]').type('pa');
        cy.xpath('//ul[@id="ui-id-1"]').find('.ui-menu-item').then(($var) => {
            if(($var.text()) == 'Panama') {
                cy.wrap($var).click();
            }
        });


        // cy.xpath('//ul[@id="ui-id-1"]')
        // cy.get('.ui-menu-item')
        // cy.xpath('//div[@id="ui-id-31"]').click();  
    });

    it('Drop down', () => {
        cy.visit('https://rahulshettyacademy.com/AutomationPractice/');
        cy.xpath('//select[@id="dropdown-class-example"]').select('option1');
        cy.xpath('//select[@id="dropdown-class-example"]').select('option2');
        cy.xpath('//select[@id="dropdown-class-example"]').select('option3');
    });


    it('Checkbox', () => {
        cy.visit('https://rahulshettyacademy.com/AutomationPractice/');
        cy.xpath('//input[@id="checkBoxOption1"]').check();
        cy.xpath('//input[@id="checkBoxOption1"]').uncheck();
        cy.xpath('//input[@id="checkBoxOption2"]').check();
        cy.xpath('//input[@id="checkBoxOption2"]').uncheck();
        cy.xpath('//input[@id="checkBoxOption3"]').check();
        cy.xpath('//input[@id="checkBoxOption3"]').uncheck();       
    });


    it('Alert Messages', () => {
        cy.visit('https://rahulshettyacademy.com/AutomationPractice/');
        cy.xpath('//input[@id="name"]').type("Sanket")
        cy.xpath('//input[@id="alertbtn"]').click();
        cy.on('window:alert', ($var) => {
            expect($var).to.equal('Hello Sanket, share this practice page and share your knowledge');

        });
    });


    it('Alert Messages', () => {
        cy.visit('https://rahulshettyacademy.com/AutomationPractice/');
        cy.xpath('//input[@id="name"]').type("Sanket")
        cy.xpath('//input[@id="confirmbtn"]').click();
        cy.on('window:confirm', ($var) => {
            expect($var).to.equal('Hello Sanket, Are you sure you want to confirm?');            
        });
    });


    it('Mouse Hover', () => {
        cy.visit('https://rahulshettyacademy.com/AutomationPractice/');
        cy.xpath('//button[@id="mousehover"]').invoke('show');
        cy.contains('Top').click({ force : true});
        cy.url().should('include','top');        
    });


    it('Mouse Hover 2', () => {
        cy.visit('https://rahulshettyacademy.com/AutomationPractice/');
        cy.xpath('//button[@id="mousehover"]').invoke('show');
        cy.contains('Reload').click({ force : true});
        cy.url().should('include','https://rahulshettyacademy.com');      
    });

    it('Table no 1 of 11111', () => {
        cy.visit('https://rahulshettyacademy.com/AutomationPractice/');
        cy.xpath('//table[@id="product"]/tbody/tr[2]/td[3]').then(($ere) => {
            if($ere.text() == "30" ){
                cy.log($ere.text());
            }
        })   
    });


    it('Table no 1 of 22222', () => {
        cy.visit('https://rahulshettyacademy.com/AutomationPractice/');
        cy.xpath('//table[@id="product"]/tbody/tr[11]/td[3]').then(($ere) => {
            if($ere.text() == "0" ){
                cy.log($ere.text());
            }
        })   
    });


    it('Table no 2 of 11111', () => {
        cy.visit('https://rahulshettyacademy.com/AutomationPractice/');
        cy.xpath('//table[@id="product"]/tbody/tr[2]/td[1]').then(($ere2) => {
            if($ere2.text() == "Ben"){
                cy.log($ere2.text());
            }
        });
    });


    it('Table no 2 of 22222', () => {
        cy.visit('https://rahulshettyacademy.com/AutomationPractice/');
        cy.xpath('//table[@id="product"]/tbody/tr[4]/td[1]').then(($ere2) => {
            if($ere2.text() == "lvory"){
                cy.log($ere2.text());
            }
        });
    });


    it('i - frames', () => {      
        cy.visit('https://rahulshettyacademy.com/AutomationPractice/')
        cy.frameLoaded('#courses-iframe')    // old website
        cy.iframe().contains('Job Support').click();   // new website we have opened here
        // cy.iframe help us to change the site....i.e.   Job Support
    });  
    

    it('Join now link ', () => { //for iframe we install iframe  npm install cypress-iframe
        cy.visit('https://rahulshettyacademy.com/AutomationPractice/')
        cy.frameLoaded('#courses-iframe')
        cy.iframe().contains('JOIN NOW').click();
      
        cy.frameLoaded('#courses-iframe')
        cy.iframe().contains('Job Support').click()
    });


    it('', () => {
        
    });

});