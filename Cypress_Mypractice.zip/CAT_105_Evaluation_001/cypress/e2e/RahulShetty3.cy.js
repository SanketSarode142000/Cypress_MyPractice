describe('RahulShetty3Alert', () => {
//     it('Alert', () => {
//         cy.visit('https://rahulshettyacademy.com/AutomationPractice/');
//         cy.xpath('//input[@name="enter-name"]').click();
//         cy.on('Window:alert',(text) => {
//             expect(text).to.contains('Hello , share this practice page and share your knowledge');
//         });        
//     });

    
//     it('Confirm', () => {
//         cy.visit('https://rahulshettyacademy.com/AutomationPractice/');
//         cy.xpath('//input[@class="btn-style"]').click({multiple:true});
//         // cy.xpath('#confirmbtn').click();
//         cy.on('Window:confirm',(text) => {
//             expect(text).to.contains('Hello , Are you sure you want to confirm?');
//             return true;
//         });        
//     });


// it('NameAlert', () => {
//     cy.visit('https://rahulshettyacademy.com/AutomationPractice/');
//     cy.get('#name').type('Sanket');
//     cy.get('#alertbtn').click();
//     cy.on('Window:alert',(text) => {
//         expect(text).to.contains(suppose);
//     });  
// });


// it('NameAlert', () => {   
//     cy.visit('https://rahulshettyacademy.com/AutomationPractice/');
//     var kkk = "Sanket";
//     cy.get('#name').type(kkk);
//     cy.get('#alertbtn').click();
//     cy.on('Window:alert',(text) => {
//         expect(text).to.contains(kkk);
//     });  
// });


    // it('MouseHover', () => {
    //     // var namee = "Sanket";
    //     cy.visit('https://rahulshettyacademy.com/AutomationPractice/');
    //     cy.get('#mousehover').invoke('show')
    //     cy.contains('Top').click({force:true})
    //     // cy.url().should('include','https://rahulshettyacademy.com/AutomationPractice/#top');
    //     cy.url().should('include','top');      
    // });




    // it('MouseHover', () => {
    //     var namee = "Sanket";
    //     cy.visit('https://rahulshettyacademy.com/AutomationPractice/');
    //     cy.get('#mousehover').invoke('show')
    //     cy.contains('Reload').click({force:true})
    //     // //cy.url().should('include','https://rahulshettyacademy.com/AutomationPractice/#top');  //false
    //     cy.url().should('include','top');

        
    // });


    // it('RightClick', () => {
    //     cy.visit('https://rahulshettyacademy.com/AutomationPractice/');
    //     cy.get('#alertbtn').rightclick();

        
    // });


    // it('demoGuruRightClick', () => {
    //     cy.visit('https://demo.guru99.com/test/simple_context_menu.html');
    //     cy.get('.context-menu-one').rightclick();       
    // });


    // it('DoubleClick', () => {
    //     cy.visit('https://demo.guru99.com/test/simple_context_menu.html');
    //     cy.xpath('//button[@ondblclick="myFunction()"]').dblclick();    
    // });





});