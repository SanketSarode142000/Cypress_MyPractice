
describe('flipkart', () => {
    it('Login', () => {
        cy.visit('https://www.flipkart.com/');
        cy.get('.q8WwEU')
        cy.get('._3zsGrb')
        cy.get('._2msBFL')
        // cy.get('._38VF5e')
        cy.get('._38VF5e')   //click()
        cy.get('._25HC_u')
        cy.get('._25HC_u')
        cy.get('.css-175oi2r')
        cy.get('.css-175oi2r')
        cy.get('._3qmi1z')
        cy.get('.yAlKeh')
        cy.get('#seo--footer')
        cy.get('#__LOADABLE_REQUIRED_CHUNKS__')
        cy.get('._1ch8e_')
        cy.get('.zlQd20 ')
        cy.get('._1yQHx8')
        cy.get('._3qmi1z')
        cy.get('._2o9o_t')
        cy.get('.css-175oi2r')
        cy.get('._3qmi1z')
        cy.get('._1yQHx8')
        // cy.get(':nth-child(2) > ._38VF5e > ._3jeYYh > ._1Us3XD > .H6-NpN > ._1TOQfO').click()
        // cy.get('.r4vIwl').type('7888054059')
        // cy.get('.QqFHMw').click();

    });
});