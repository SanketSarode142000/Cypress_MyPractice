describe('Simple Form Practice', () => {
    it('Basic check', () => {
        cy.visit('https://v1.training-support.net/selenium/simple-form');
        cy.title().should('eq','Simple Form');
        cy.url().should('includes','https://v1.training-support.net/');
        cy.url().should('eq','https://v1.training-support.net/selenium/simple-form');        
    });

   it('Login', () => {
    cy.visit('https://v1.training-support.net/selenium/simple-form');
    cy.xpath('//input[@placeholder="First Name"]').type("Sanket");
    // cy.xpath('//input[@placeholder="First Name"]').then((var1) => {
    //     expect(var1).to.have.attr('placeholder','First Name');
    //     cy.wrap(var1).type('Sanket')
    // });


    cy.xpath('//input[@placeholder="Last Name"]').type('Sarode');
    cy.xpath('//input[@type="email"]').type('sanket.sarode@gmail.com');
    cy.xpath('//input[@pattern="[0-9]{10}"]').type('1234567890');
    cy.xpath('//textarea[@rows="2"]').type("Hiii")

    // cy.xpath('//div[@class="field"]').type('Hiii');
    // cy.xpath('(//div[@class="field"])[1]').type('Hiii');   
   });


   it('Submit', () => {
    cy.visit('https://v1.training-support.net/selenium/simple-form');
    cy.xpath('//input[@class="ui green button"]').click();
    cy.on('windows:submit', ($var) => {
        expect(($var)).to.contains('Thank You for reaching out to us, Sanket Sarode')
    })
   }); 

    it('Clear', () => {
        cy.visit('https://v1.training-support.net/selenium/simple-form');
        cy.xpath('//input[@class="ui button"]').click();
        
    });

    


});