describe('BigBasket', () => {
    it('Login', () => {
        cy.visit('https://www.bigbasket.com/')
        cy.xpath('//span[contains(text(),"Home and Kitchen")]')
        cy.xpath('//span[contains(text(),"Beauty and Hygiene")]')
        cy.xpath('//span[contains(text(),"Top Offers")]')
        cy.xpath('//span[contains(text(),"Fruits and Vegetables")]')
        cy.xpath('//span[contains(text(),"Snacks Store")]')  
        cy.xpath('//span[@class="Label-sc-15v1nk5-0 CustomSection___StyledLabel-sc-1cgvpp1-7 gJxZPQ jdexhY"]').then((var1) => {
            expect(var1.text()).to.contains('Cleaning & Household')
        });
        cy.xpath('//span[@class="Label-sc-15v1nk5-0 CustomSection___StyledLabel-sc-1cgvpp1-7 gJxZPQ jdexhY"]').then((var2) => {
            expect(var2.text()).to.contains('Beverages');
        });
        cy.xpath('//span[@class="Label-sc-15v1nk5-0 CustomSection___StyledLabel-sc-1cgvpp1-7 gJxZPQ jdexhY"]').then((var3) => {
            expect(var3.text()).to.contains('Top Offers')
        });
    });
});




// describe('BigBasket', () => {
//     it('Login', () => {
//         cy.visit('https://www.bigbasket.com/');




//     });
// });