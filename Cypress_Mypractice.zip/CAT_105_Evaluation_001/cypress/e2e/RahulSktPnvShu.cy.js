describe('RahulAcademy', () => {
    it('Radio', () => {
        cy.visit('https://rahulshettyacademy.com/AutomationPractice/');
        cy.xpath('//label[@for="radio1"]').click();        
    });


    it('Search country', () => {
        cy.visit('https://rahulshettyacademy.com/AutomationPractice/');
        cy.xpath('//input[@id="autocomplete"]').type('ja');
        cy.get('#ui-id-1').find('.ui-menu-item').each((var1) => {
            if((var1.text()) == "Japan"){
                cy.wrap(var1).click();
                return;
            }
        });
    });


    it('Search country', () => {
        cy.visit('https://rahulshettyacademy.com/AutomationPractice/');
        cy.xpath('//input[@id="autocomplete"]').type('ind');
        cy.get('#ui-id-1').find('.ui-menu-item').each(($var)=>{
            if(($var.text()) == "India" ){
                cy.wrap($var).click();
                return;
            }
        });
    });


     it('Search', () => {
        cy.visit('https://rahulshettyacademy.com/AutomationPractice/');
        cy.get('[placeholder="Type to Select Countries"]').type('ind');
        cy.xpath('//ul[@id="ui-id-1"]').find('.ui-menu-item').each(($var) => {
            if(($var.text()) == "British Indian Ocean Territory"){
                cy.wrap($var).click();
                return;
            }
        });       
    });


    it('Dropdown Example', () => {
        cy.visit('https://rahulshettyacademy.com/AutomationPractice/');
        cy.xpath('//select[@id="dropdown-class-example"]').select('Option3')
    });


    it('Checkbox Example', () => {
        cy.visit('https://rahulshettyacademy.com/AutomationPractice/');
        // cy.xpath('//div[@class="right-align"]')
        cy.xpath('//input[@id="checkBoxOption3"]').check();
        // cy.xpath('//input[@id="checkBoxOption3"]').each(($var2) => {
        //     if(($var2.text()) == 'Option3'){
        //         cy.wrap($var2).check();            }
        // })   

    });


    it('Alert', () => {
        cy.visit('https://rahulshettyacademy.com/AutomationPractice/');
        cy.get('#name').type("Sanket");
        cy.xpath('//input[@id="alertbtn"]').click();
        cy.on('window:alert' , ($var) => {
            expect(($var)).to.contains('Hello Sanket, share this practice page and share your knowledge')
        })       
    });


    it('Confirm', () => {
            cy.visit('https://rahulshettyacademy.com/AutomationPractice/');
            cy.get('#confirmbtn');
            cy.on('window:confirm' , (str2) => {
                expect((str2)).to.contains('Hello Sanket, Are you sure you want to confirm?');
            })          
        });


     it('MouseHover', () => {
        // var namee = "Sanket";
        cy.visit('https://rahulshettyacademy.com/AutomationPractice/');
        cy.get('.mouse-hover').invoke('show')
        cy.contains('Top').click({force:true})
        // cy.url().should('include','https://rahulshettyacademy.com/AutomationPractice/#top');
        cy.url().should('include','top');      
    });


    it('Table 1', () => {
        cy.visit('https://rahulshettyacademy.com/AutomationPractice/');
         
    });

    
});