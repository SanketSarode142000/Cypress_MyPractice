// describe('Cura Make Appointment', () =>{
// https
//   it('Visit the URL',function(){
      
//   });


//   it('Click on Make Appointment',()=>{
//     cy.visit('https://katalon-demo-cura.herokuapp.com/');
//       cy.get('#btn-make-appointment').click();
//     //   cy.wait('10000');
//       cy.get('#txt-username').type('John Doe');
//       cy.get('#txt-password').type('ThisIsNotAPassword');
//       cy.get('#btn-login').click();
//   });


//   it('Make Appointment',function(){
//     cy.visit('https://katalon-demo-cura.herokuapp.com/');
//     cy.get('#btn-make-appointment').click();
//     //   cy.wait('10000');
//       cy.get('#txt-username').type('John Doe');
//       cy.get('#txt-password').type('ThisIsNotAPassword');
//       cy.get('#btn-login').click();
//     //   cy.xpath('//option[@value="Hongkong CURA Healthcare Center"]').select('Hongkong CURA Healthycare Centre');
//       cy.get('#chk_hospital_readmission').click();
//       cy.get('#radio_program_medicad').click();
//       cy.get('#txt_visit_date').type('30/03/2020');
//       cy.get('#txt_comment').click({force: true});
//       cy.get('#txt_comment').type('Sanket Sarode is available for every one.');
//       cy.get('#btn-book-appointment').click();
//   });


//   it('Verify appointment', function(){
    // cy.visit('https://katalon-demo-cura.herokuapp.com/');
//       cy.get('#h2').contains('Appointment Confirmation');
//       cy.get('#comment').contains('Sanket Sarode is available for every one.');
//   });


// });






// describe('Testing', () => {
//     it('login', () => {
//         cy.visit('https://the-internet.herokuapp.com/login')
//         cy.get('#username').type('tomsmith')
//         cy.get('#password').type('SuperSecretPassword!')
//         cy.get('.fa').click()
//         // cy.xpath('//i[@class="fa fa-2x fa-sign-in"]').click();
//     });
// });



// describe('Testing', () => {
//     it('Submit', () => {
//         cy.visit('https://v1.training-support.net/selenium/simple-form');
//         cy.get('#firstName').type("Sanket");
//         cy.get('#lastName').type('Sarode');
//         cy.get('#email').type('sanket@gmail.com');
//         cy.get('#number').type('7888054059');
//         cy.get('textarea').type('Hiii');
//         // cy.get('.form > .spaced > :nth-child(1) > .ui').click();
//         cy.xpath('//input[@value="submit"]').click();
//         // cy.get('[type="submit"]').click();
//         // cy.get('.submit').click();
//         // cy.get('.ui.field > .ui').click();
//         cy.get('.ui.field > .ui').click();
//     });
// });





// describe('Testing', () => {
//     it('Search', () => {
//         cy.visit('https://demo.opencart.com/');
//         // cy.get('.form-control form-control-lg');
//         cy.get('.Search').click();        
//     });
// });





// describe('HerokuooooApp', () => {
//     it('Login', () => {
//         cy.visit('https://the-internet.herokuapp.com/login')
//         cy.get('#username').type('tomsmith')
//         cy.get('#password').type('SuperSecretPassword!')
//         cy.get('.radius').click()
//     });
// });






// describe('HerokuooooApp', () => {
//     it('Login', () => {
//         cy.visit('https://the-internet.herokuapp.com/login');
// //         cy.url().should('eq','https://the-internet.herokuapp.com/login');

//         cy.url().should('eq','https://the-internet.herokuapp.com/login');
//         cy.title().should('include','Internet');
//         cy.xpath('//input[@name="username"]').type('tomsmith');
        
//         cy.get('[name="password"]').type('SuperSecretPassword!');
//         cy.get('[type="submit"]').click();

//         //// cy.xpath('//input[@placeholder="Try Saree, Kurti or Search by Product Code"]').type('puma shoes');

//         // cy.get('#username').type('tomsmith')
//         // cy.get('#password').type('SuperSecretPassword!')
//         cy.get('.radius').click()
//     });
// });










// describe('HerokuooooApp', () => {
//     it('Login', () => {
//         cy.visit('https://the-internet.herokuapp.com/login');
//         cy.url().should('eq','https://the-internet.herokuapp.com/login');
//     });
// });





// describe('Redbus', () => {
//     it('Login', () => {
//         cy.visit('https://www.redbus.com/');
//         // cy.wait(7000);
//         cy.xpath('//div[@class="search-lbl"]');
//     });
// });





// describe('Redbus', () => {
//     it('Login', () => {
//         cy.visit('https://www.redbus.com/');
//        // // cy.xpath('//button[fdprocessedid="pdyvdc"]');
//         // cy.get('.search-lbl')
//         // cy.wait(7000);
//         cy.xpath('//div[@class="search-lbl"]');
//         // cy.xpath('//div[@search-lbl]')
//         // cy.wait(7000);
//         // cy.xpath('//div')

//         // cy.xpath('//[id="mBWrapper"]').click();
        
//     });
// });





// describe('Redbus', () => {
//     it('Login', () => {
//         cy.visit('https://www.redbus.com/');
//         cy.xpath('//div[@class="search-lbl"]');
//         // cy.xpath('//section[@class="rh_main"]');
//         cy.xpath('//div[@class="customer-headwrapper"]');
//         cy.xpath('//div[@class="cust-content"]');
//         cy.xpath('//div[@class="safety-wrapper"]');
//         cy.xpath('//div[@class="btn-container"]');
//         cy.xpath('//div[@class="pop-wrapper"]');
//         cy.xpath('//div[@class="pop-head"]');
//         cy.xpath('//div[@class="exit-reshedule-confirm hide"]');
//         cy.xpath('//div[@class="msg-header"]');
//         cy.xpath('//header[@class="home-only-header fixer1"]');
//         cy.xpath('//div[@id="rdc-root"]');
//         cy.xpath('//div[@class="grey-vertical"]');
//         cy.xpath('//div[@class="returndate input-box "]');
//         cy.xpath('//label[@class="lbl"]');
//         cy.xpath('//div[@class="air-wrapper"]');
//         cy.xpath('//div[@class="cust-content"]');
//         cy.xpath('//div[@class="slick-slider slick-initialized"]');
//         cy.xpath('//div[@class="slick-custom-arrow prev"]');
//         cy.xpath('//div[@class="slick-custom-arrow next"]');
//         cy.xpath('//div[@class="safety-button"]');
//     });
// });







// describe('flipkart', () => {
    // it('Login') => {
        // cy.visit('https://www.flipkart.com/');
        // cy.get('.q8WwEU')
        // cy.get('._3zsGrb')
        // cy.get('._2msBFL')
        // // cy.get('._38VF5e')
        // cy.get('._38VF5e')   //click()
        // cy.get('._25HC_u')
        // cy.get('._25HC_u')
        // cy.get('.css-175oi2r')
        // cy.get('.css-175oi2r')
        // cy.get('._3qmi1z')
        // cy.get('.yAlKeh')
        // cy.get('#seo--footer')
        // cy.get('#__LOADABLE_REQUIRED_CHUNKS__')
        // cy.get('._1ch8e_')
        // cy.get('.zlQd20 ')
        // cy.get('._1yQHx8')
        // cy.get('._3qmi1z')
        // cy.get('._2o9o_t')
        // cy.get('.css-175oi2r')
        // cy.get('._3qmi1z')
        // cy.get('._1yQHx8')

//         cy.get(':nth-child(2) > ._38VF5e > ._3jeYYh > ._1Us3XD > .H6-NpN > ._1TOQfO').click()
//         cy.get('.r4vIwl').type('7888054059')
//         cy.get('.QqFHMw').click();

//         // cy.get('.xTaogf').click() 
                
//         // cy.get('button').click({ force: true }).should('have.attr', 'href')
      
//         // cy.get(':nth-child(2) > ._38VF5e > ._3jeYYh > ._1Us3XD > .H6-NpN > ._1TOQfO').click()
//         // cy.get('.r4vIwl').type('7888054059')
//         // cy.get('.QqFHMw').click();

//           cy.get('._2puWtW _3a3qyb').click();

//         cy.get('.Pke_EE').click().type('mobile');
//         cy.get('img._2puWtW _3a3qyb')

//         cy.get('[data-observerid-43bb9243-5da2-48ba-bf59-f3a2cde7fe27="f9778465-cabd-449a-95ae-6d5e8e4d751d"] > .YBLJE4 > ._3ETuFY > ._2GaeWJ > ._2puWtW')

//         cy.get('svg.http://www.w3.org/2000/svg')

//         cy.type('.mobile');
//         cy.get('.zDPmFV')
//         cy.get('.q8WwEU').click();
//         cy.get('._2nl6Ch').click();
//         cy.get('._2NhoPJ').click();
//         cy.get('._2BAUXN').click();
       
//     });
// });









// describe('e_Bay', () => {
//     it('login', () => {
//         cy.visit('https://www.ebay.com/')
//         cy.xpath('//div[@id="vl-flyout-nav"]').click()
//         cy.xpath('//div[@class="b-visualnav__title"]')
//         cy.xpath('//img[@alt="1"]')
//         cy.xpath('//img[@class="b-img"]')
//         cy.xpath('//li[@class="carousel__snap-point"]')

//         // // cy.xpath('//[@"gh-td"]')
//         // // cy.get('.vl-carousel__item')
//         // // cy.get('.vl-popular-destinations-evo__name')

//         // // cy.xpath('//div[@class="grey-vertical"]');       
//     });
// });







// describe('eBay', () => {
//     it('textFunction', () => {
//         cy.visit('https://www.ebay.com/')
//         cy.xpath('//h2[text()=("Additional site navigation")]')
//         cy.xpath('//a[text()=("AdChoice")]')
//         cy.xpath('//a[text()=("Consumer Health Data")]')
//         cy.xpath('//a[text()=("Payments Terms of Use")]')
//         cy.xpath('//a[text()=("Cookies")]')        
//     });
// });









// describe('MakeMyTrip', () => {
//     it('Login', () => {
//         cy.visit('https://www.makemytrip.com/')

//         //   10 taas wait kelo



        
//     });
// });








// describe('BigBasket', () => {
//     it('Login', () => {
//         cy.visit('https://www.bigbasket.com/')
//         cy.xpath('//span[contains(text(),"Home and Kitchen")]')
//         cy.xpath('//span[contains(text(),"Beauty and Hygiene")]')
//         cy.xpath('//span[contains(text(),"Top Offers")]')
//         cy.xpath('//span[contains(text(),"Fruits and Vegetables")]')
//         cy.xpath('//span[contains(text(),"Snacks Store")]')        
//     });
// });










// describe('Redbus', () => {
//     it('Login', () => {
//         cy.visit('https://www.redbus.com/');
//         cy.xpath('//div[@class="source input-box "]');
//         // cy.xpath('//input[@id="#src"]').type("Indianapolis, USA");
       
//         cy.get('.source')
//         // cy.get('.source > .lbl')
//         cy.get('#src').type('Indianapolis, USA', { force: true })

        
        
//     });
// });







