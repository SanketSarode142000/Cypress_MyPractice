// installed cypress using npm install cypress open --save-dev
// opened cypress using npx cypress open
// run using npx cypress run
describe('Simple_Form', () => {
    it('Login', () => {
        //   visiting the url of the website
        cy.visit('https://v1.training-support.net/selenium/simple-form');
        //   providing all the valid details  like first name, last name, email, number, message.
        // it('url_check', () => {
        cy.get('#firstName').type("Sanket");
        cy.get('#lastName').type("Sarode");
        cy.get('#email').type("sanketsarode142000@gmail.com");
        cy.get('#number').type("7888054059");
        cy.get('textarea').type("Hello!");
        // cy.xpath('//textarea[@rows="2"]').type("5555")
        // })
    });


    //     //    clicking on submit button
        it('submitting_details', () => {
            cy.visit('https://v1.training-support.net/selenium/simple-form');           
            cy.xpath('//input[@type="submit"]').click();
        })
 
        
        //    checking the title of the website
        it('title_check', () => {
            cy.visit('https://v1.training-support.net/selenium/simple-form');
            cy.title().should('include',"Simple Form");
        })       


        //checking the url after submitting all the details.
        it('url_check', () => {
            cy.visit('https://v1.training-support.net/selenium/simple-form?');
            cy.url().should('eq','https://v1.training-support.net/selenium/simple-form?');
        })      
});