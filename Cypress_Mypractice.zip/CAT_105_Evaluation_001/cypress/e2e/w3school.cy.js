// describe('rahulshetty', () => {
//     it('alert', () => {
//         cy.visit('')
        
//     });
// });




describe('rahulshetty', () => {
    it('alert', () => {
        var suppose = "Sanket"
        cy.visit('')
        
    });
});