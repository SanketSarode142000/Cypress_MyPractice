// describe('Crickbuzz', () => {
//     it('live', () => {
//         cy.visit('https://www.cricbuzz.com/');
//         cy.xpath('//a[@class="cb-hm-mnu-itm"]').should('have.text','Live ScoresScheduleArchives').click();
        
//     });
// });






