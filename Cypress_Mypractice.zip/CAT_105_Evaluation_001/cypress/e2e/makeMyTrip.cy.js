describe('MakeMyTrip', () => {
    it('Login', () => {
        cy.visit('https://www.makemytrip.com/');
        // I am unable to open make my trip website using this link.
        



        
    });
});



