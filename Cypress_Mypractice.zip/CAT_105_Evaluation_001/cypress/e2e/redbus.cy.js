// describe('Redbus', () => {
//     it('Login', () => {
//         cy.visit('https://www.redbus.com/');
//         cy.xpath('//div[@class="search-lbl"]');
//         cy.xpath('//div[@class="customer-headwrapper"]');
//         cy.xpath('//div[@class="cust-content"]');
//         cy.xpath('//div[@class="safety-wrapper"]');
//         cy.xpath('//div[@class="btn-container"]');
//         cy.xpath('//div[@class="pop-wrapper"]');
//         cy.xpath('//div[@class="pop-head"]');
//         cy.xpath('//div[@class="exit-reshedule-confirm hide"]');
//         cy.xpath('//div[@class="msg-header"]');
//         cy.xpath('//header[@class="home-only-header fixer1"]');
//         cy.xpath('//div[@id="rdc-root"]');
//         cy.xpath('//div[@class="grey-vertical"]');
//         cy.xpath('//div[@class="returndate input-box "]');
//         cy.xpath('//label[@class="lbl"]');
//         cy.xpath('//div[@class="air-wrapper"]');
//         cy.xpath('//div[@class="cust-content"]');
//         cy.xpath('//div[@class="slick-slider slick-initialized"]');
//         cy.xpath('//div[@class="slick-custom-arrow prev"]');
//         cy.xpath('//div[@class="slick-custom-arrow next"]');
//         cy.xpath('//div[@class="safety-button"]');
//     });
// });




describe('Redbus', () => {
    it('Login', () => {
        cy.visit('https://www.redbus.com/');


        cy.xpath('//div[@class="search-wrapper"]')
        cy.xpath('//div[@class="source input-box "]').click({force:true})
        cy.xpath('//input[@id="src"]').type('India');

        cy.xpath('//div[@class="source input-box "]');
        // cy.xpath('//input[@id="#src"]').type("Indianapolis, USA");
       
        cy.get('.source')
        // cy.get('.source > .lbl')
        cy.get('#src').type('Indianapolis, USA', { force: true })        
    });
});