// describe('rahulshetty', () => {
//     it('Login', () => {
//     cy.visit('https://rahulshettyacademy.com/AutomationPractice/');
//     cy.get('#dropdown-class-example').select('Option3')
//     cy.get('#checkBoxOption1').check()
//     cy.get('[value="radio3"]').check()
//     cy.get('[value="radio1"]').click()
//     cy.xpath('//label[@for="benz"]').click()
//     });
// });




// describe('rahulshetty', () => {
//     it('Login', () => {
//     cy.visit('https://rahulshettyacademy.com/AutomationPractice/');

//     // cy.url().should('eq','https://rahulshettyacademy.com/AutomationPractice/');
//     // cy.title().should('contain','Practice Page');
//     // // cy.title().should('include','Practice Page');
//     // cy.xpath('//label[@for="radio1"]')
//     // cy.xpath('//input[@value="radio1"]').click();
//     // cy.xpath('//input[@value="radio2"]').click();


//         cy.xpath('//input[@placeholder="Type to Select Countries"]').type('Ind');
//         // cy.get('[placeholder = "Type to Select Countries"]').type('ind')
//         cy.get('#ui-id-1').find('.ui-menu-item').each(($variable) => {
//             if(($variable.text()) == "India"){
//                 cy.wrap($variable).click();
//                 return;
//             };
//         });   
//     });
// });