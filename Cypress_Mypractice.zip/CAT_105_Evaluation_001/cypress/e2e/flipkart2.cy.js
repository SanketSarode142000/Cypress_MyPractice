// const { expect } = require("chai");
describe('Flipkart', () => {
    it('Search', () => {
        cy.visit('https://www.flipkart.com/');
        cy.get('.Pke_EE').then((variable) => {
            expect(variable).to.have.attr('placeholder','Search for Products, Brands and More');
            cy.wrap(variable).type('I-phone');          
        });  
    });


    it('Electronics', () => {
        cy.visit('https://www.flipkart.com/');
        cy.xpath('(//span[@class="_1XjE3T"])[4]').then((variable) => {
            expect(variable.text()).to.contains('Electronics');
        });    
    });

    
    it('Electronic', () => {
        cy.visit('https://www.flipkart.com/');
        // cy.xpath('//div[@class="_3sdu8W emupdz"]')[4].click();
        // cy.get('._1XjE3T').then((var1) => {
            cy.xpath('(//span[@class="_1XjE3T"])[4]').then((var1) => {
            expect(var1).to.have.attr('aria-label','Electronics');
            cy.wrap(var1).click();
        });
    });


        // cy.get('./elec-big-dussehra-24-sale-store?fm=neo%2Fmerchandising&iid=M_b3b73639-0093-446e-baad-a76909587d2c_1_KUZ8W60OFFMO_MC.KCBBC8GGWR9V&otracker=hp_rich_navigation_4_1.navigationCard.RICH_NAVIGATION_Electronics_KCBBC8GGWR9V&otracker1=hp_rich_navigation_PINNED_neo%2Fmerchandising_NA_NAV_EXPANDABLE_navigationCard_cc_4_L0_view-all&cid=KCBBC8GGWR9V').click().then((variable2) => {
        // cy.get('[data-observerid-1b526db0-d2ad-4ab4-9df3-f9c6c067e652="ff8db165-289d-4437-a95f-68bc62138b41"] > .YBLJE4 > ._1XjE3T > span').click().then((variable2) => {
        // cy.get('._1XjE3T').click().then((variable2) => {
            // expect(variable2);

        // });
    // });




// describe('Flipkart practice', () => {
//     it('login', () => {
//         cy.visit('https://www.flipkart.com/');
//         cy.xpath('(//span[@class="_1XjE3T"])[4]').then(($variable) => {
//             expect($variable.text()).to.contains('Electronics');
//         });       
//     });


// });




});