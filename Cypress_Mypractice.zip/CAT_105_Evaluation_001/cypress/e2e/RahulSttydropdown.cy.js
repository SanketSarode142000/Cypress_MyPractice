describe('RahulShttyDropdown', () => {
    it('Radio', () => {
        cy.visit('https://rahulshettyacademy.com/AutomationPractice/');
        cy.get('#radio-btn-example');
        cy.get('#checkBoxOption1').click();
        cy.get('[value="radio1"]').click();
        cy.get('[value="radio2"]').click(); 
        
        cy.get('[value="radio3"]').click();              // get   

        // // //cy.get('[value="radio3"]').uncheck();  
        cy.xpath('//label[@for="radio3"]').click();      // xpath 
               
    });



    it('Dropdown', () => {
        cy.visit('https://rahulshettyacademy.com/AutomationPractice/');
        cy.get('#dropdown-class-example').select('option1');      // 1 way
        cy.xpath('//select[@name="dropdown-class-example"]').select('option2');  // 2 way
        cy.xpath('//select[@name="dropdown-class-example"]').select('option3');
        

        //cy.get('#dropdown-class-example').select('option1').should('include.text','Option1');
        //cy.get('#dropdown-class-example').select('option1').should('include.text','Option2');       
    });


    it.only('CheckBoxExample', () => {
        cy.visit('https://rahulshettyacademy.com/AutomationPractice/');
        cy.get('#checkBoxOption1').check();
        cy.get('#checkBoxOption2').check();
        cy.get('#checkBoxOption3').check();                          // get check
        // cy.get('#checkBoxOption3').uncheck();                        // get uncheck                       
        

        // //cy.xpath('//input[@id="checkBoxOption3"]').check();     // xpath check
        // //cy.xpath('//input[@id="checkBoxOption3"]').uncheck();   // xpath uncheck
    });



    it.only('DynamicDropDown', () => {
        cy.visit('https://rahulshettyacademy.com/AutomationPractice/');
        cy.get('[placeholder="Type to Select Countries"]').type('ind');
        cy.xpath('//ul[@id="ui-id-1"]').find('.ui-menu-item').each(($var) => {
            if(($var.text()) == "British Indian Ocean Territory"){
                cy.wrap($var).click();
                return;
            }
        });       
    });




    it('DynamicDropDown', () => {
        cy.visit('https://rahulshettyacademy.com/AutomationPractice/');
        cy.get('[placeholder="Type to Select Countries"]').type('ind');
        cy.xpath('//ul[@id="ui-id-1"]')
        cy.get('.ui-menu-item').each(($var) => {
            if(($var.text()) == "British Indian Ocean Territory"){
                cy.wrap($var).click();
                return;
            }
        });       
    });



    // it('DynamicDropDown', () => {
    //     cy.visit('https://rahulshettyacademy.com/AutomationPractice/');
    //     cy.get('[placeholder="Type to Select Countries"]').type('ind');
    //     cy.xpath('//ul[@id="ui-id-1"]').find('.ui-menu-item').each(($var) => {
    //         if(($var.text()) == "British Indian Ocean Territory"){
    //             cy.wrap($var).click();
    //             return;
    //         }
    //     });       
    // });



    it('Login', () => {
        cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/auth/login');
        cy.get('[name="username"]').type('Admin');
        cy.get('[name="password"]').type('admin123');
        cy.get('[type"submit"]').click();
        cy.wait(5000);      
    });

    
// });




// describe('RahulDynamic', () => {
//     it('DropDown', () => {
//         cy.visit('https://rahulshettyacademy.com/AutomationPractice/');
//         cy.xpath('//select[@id="dropdown-class-example"]').select('Option3');        
//     });




});