let array = [1,5,2,2,3,3,4];
for(i=0;i<array.length;i++){
    for(j=0;j<array.length;j++){
        if(array[i] == array[j]){
            i++;
        }
    }console.log(array[j]);
}













// for(i=0;i<array.length;i++){
//     let k = +(array[i]);
//     let count = 0;
//     for(j=1;j<=k;j++){
//         // console.log(k)
//         if(k%j===0){
//             // console.log("dcz bnb bn")
//             count++;
            
//         }
//     }if(count===2){
//         console.log("Yes")
//         console.log(k)
//         // break;
//     }
// }


