describe('eBay', () => {
    it('login', () => {
        cy.visit('https://www.ebay.com/');
        cy.xpath('//div[@id="vl-flyout-nav"]').click();
        cy.xpath('//div[@class="b-visualnav__title"]');
        cy.xpath('//img[@alt="1"]');
        cy.xpath('//img[@class="b-img"]');
        cy.xpath('//li[@class="carousel__snap-point"]');

        //// cy.xpath('//[@"gh-td"]')
        //// cy.get('.vl-carousel__item')
        // //cy.get('.vl-popular-destinations-evo__name')

        // //cy.xpath('//div[@class="grey-vertical"]');        
    });
});




// describe('eBay', () => {
//     it('textFunction', () => {
//         cy.visit('https://www.ebay.com/')
//         cy.xpath('//h2[text()=("Additional site navigation")]')
//         cy.xpath('//a[text()=("AdChoice")]')
//         cy.xpath('//a[text()=("Consumer Health Data")]')
//         cy.xpath('//a[text()=("Payments Terms of Use")]')
//         cy.xpath('//a[text()=("Cookies")]')        
//     });
// });





// working fine but what happened i dont know
 
// describe('eBay', () => {
//     it('login', () => {
//         cy.visit('https://www.ebay.com/');
//         cy.xpath('//input[@type="text"]').type('Toys');
//         cy.xpath('//a[@aria-label="toy soldiers pre 1970"]').click();
//         // cy.get('.ui-menu-item ghAC_hidden')
//         // cy.get('.ghAC_sugg ui-corner-all').click({ multiple: true });
        


//     });
// });