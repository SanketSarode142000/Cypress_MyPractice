describe('AmazonIndex', () => {
    it('Index', () => {
        cy.visit('https://www.amazon.com/');
        // cy.xpath('//div[data-cel-widget="search_result_1"][last()]');
        cy.xpath('(//script[@type="text/javascript"])[2]')
        // cy.xpath('(//script[@type="text/javascript"])[64]').click({ force: true });

// // //cy.xpath('//button[@aria-label="Search"]')

        cy.xpath('(//a[@class="nav-a"])[1]')
        cy.xpath('(//div[@id="pageContent"])[1]')        

        // cy.xpath('(//div[@id="pageContent"])[1]').click({ force: true });
        // cy.xpath('(//div[@id="pageContent"])[1]').click({ force: true });
        // cy.xpath('(//div[@id="pageContent"])').click({ force: true })

        //// cy.xpath('(//div[@id="desktop-banner"])[1]')
        //// cy.xpath('(//div[@id="desktop-banner"])[1]').click({ force: true });

        cy.xpath('(//div[@class="a-section a-spacing-none"])[1]')
        // cy.xpath('(//div[@class="a-section a-spacing-none"])[1]').click({ force: true });

        cy.xpath('(//li[@class="a-carousel-card"])[1]')
    });
});



// describe('amazon', () => {
//     it('indexxpath', () => {
//        cy.visit('https://www.amazon.in/')
//        cy.xpath("//input[@value='Go']").click();
//        cy.xpath("//select[@tabindex='0']").click();
//     });
// });