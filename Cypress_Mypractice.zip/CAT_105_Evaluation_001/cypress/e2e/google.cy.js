describe('Google home', () => {
    it('test case', () => {
        cy.visit('https://www.google.com/')
        
    });
});