describe('DynamicDropdown', () => {
    it('Dropdown', () => {
        cy.visit('https://rahulshettyacademy.com/AutomationPractice/');
        cy.get('[placeholder = "Type to Select Countries"]').type('ind')
        cy.get('#ui-id-1').find('.ui-menu-item').each(($variable) => {
            if(($variable.text()) == "Indonesia"){
                cy.wrap($variable).click();
            }
        });     
    });
});