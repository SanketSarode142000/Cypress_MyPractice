describe('Invoke', () => {
    it('Add products', () => {
        cy.visit('https://automationteststore.com/');
        cy.xpath('//a[@href="https://automationteststore.com/index.php?rt=product/category&path=68"]').invoke('show')
        cy.contains('T-shirts').click({force: true});
        // cy.xpath('//a[@href="https://automationteststore.com/index.php?rt=product/product&path=68_70&product_id=121"]').click({ multiple: true });
        cy.xpath('(//i[@class="fa fa-cart-plus fa-fw"])[1]').click();  



        cy.xpath('//a[@href="https://automationteststore.com/index.php?rt=product/category&path=65"]').invoke('show')
        cy.contains('Paperback').click({force: true})
        cy.xpath('(//i[@class="fa fa-cart-plus fa-fw"])[1]').click()


        // same part written again
        cy.xpath('//a[@href="https://automationteststore.com/index.php?rt=product/category&path=68"]').invoke('show')
        cy.contains('T-shirts').click({force: true});
        // cy.xpath('//a[@href="https://automationteststore.com/index.php?rt=product/product&path=68_70&product_id=121"]').click({ multiple: true });
        cy.xpath('(//i[@class="fa fa-cart-plus fa-fw"])[1]').click();  

    });
});