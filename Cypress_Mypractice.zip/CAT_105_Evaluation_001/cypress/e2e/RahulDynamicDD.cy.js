describe('RahulDynamic', () => {
    it('DropDown', () => {
        cy.visit('https://rahulshettyacademy.com/AutomationPractice/');
        cy.xpath('//select[@id="dropdown-class-example"]').select('Option3');        
    });
});