describe('Flipkart2', () => {

    // it('Search button functionality', () => {
    //     cy.visit('https://www.flipkart.com/');
    //     cy.xpath('//div[@class="_2SmNnR"]').click();
    //     // cy.xpath('//input[@class="Pke_EE"]').type('mobiles');
    //     //doing input using j query  because it is not working with cypress
    //     cy.xpath('//input[@class="Pke_EE"]').then(($var) => {
    //         expect($var).to.have.attr('placeholder','Search for Products, Brands and More');
    //         cy.wrap($var).type('mobiles');
    //     });
    //     cy.xpath('//button[@class="_2iLD__"]').click() 
    // });


    it('Search button functionality 2 check', () => {
        cy.visit('https://www.flipkart.com/');
        cy.xpath('//input[@class="Pke_EE"]').click();      
        cy.xpath('//input[@class="Pke_EE"]').then(($var) => {
            expect($var).to.have.attr('placeholder','Search for Products, Brands and More');
            cy.wrap($var).type('i phone')
        })
        cy.xpath('//button[@class="_2iLD__"]').click() 
    });









    // it('Search button functionality 2 check', () => {
    //     cy.visit('https://www.flipkart.com/');
    //     cy.xpath('//input[@class="Pke_EE"]').click().type('ho').click();      
    // });




    // it('Electronics button is available or not', () => {
    //     cy.visit('https://www.flipkart.com/');
    //     cy.xpath('(//div[@class="YBLJE4"])[5]').then(($ele) => {
    //         expect($ele).to.have.text('Fashion')

    //     })
        
    // });



});