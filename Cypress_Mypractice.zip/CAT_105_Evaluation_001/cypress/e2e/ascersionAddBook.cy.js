describe('booksToScrap', () => {
    it('Verify the title page', () => {
        cy.visit('https://books.toscrape.com/');
        cy.title().should('include','My Store');

        // cy.xpath('//div[@class="page-header action"]').should('include.text','All products');

        // cy.title().should('include.text','All products')
        // cy.xpath('//div[@class="page-header action"]').should('have.text','My Store');

        // cy.xpath('//div[@class="page-header action"]').should('include.text',"Products")
        // cy.xpath('//a["@title=All products | Books to Scrape - Sandbox"]').should('have.text','My Store');
    });



    it('Non Fiction Result Page', () => {
        cy.visit('https://books.toscrape.com/');

        // cy.xpath('//a[@href="index.html"]').click();

        // cy.visit('https://books.toscrape.com/catalogue/category/books/nonfiction_13/index.html');
        cy.get('a[href="catalogue/category/books/nonfiction_13/index.html"]').click();
        // cy.xpath("/html/body/div/div/div/aside/div[2]/ul/li/ul/li[12]/a")     // from....

        cy.get('h1').should('be.visible','Nonfiction');

        // cy.get('h1').should('have.text','Nonfiction');

       // // cy.xpath('//div[@class="page-header action"]').should('have.text','My Store');     
    });


    it('Add Product to a Basket', () => {
        cy.visit('https://books.toscrape.com/');
        // // cy.get('a[href="catalogue/tipping-the-velvet_999/index.html"]');     //uncomment also
        // cy.xpath('//li[@class="col-xs-6 col-sm-4 col-md-3 col-lg-3"]')
        // cy.get(':nth-child(2) > .product_pod > .product_price > form > .btn').click()
        // // cy.xpath('//article[@class="product_pod"]').click({ multiple: true });
        // cy.xpath('//article[@class="product_pod"]').first().click()

        // cy.xpath('//button[@class="btn btn-primary btn-block"]').first().click();
        cy.xpath('//button[@class="btn btn-primary btn-block"]').eq(3) // Select the fourth element (index starts from 0)
        .click();

        // now check whether product is added or not.
        cy.get(':nth-child(2) > .product_pod').click();
        cy.get('.product_pod').click({ multiple: true });
        // cy.xpath('//a[@class="thumbnail"]')
    });
});